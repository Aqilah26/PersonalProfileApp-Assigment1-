<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(145deg, #e0eafc 0%, #cfdef3 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        .container { max-width: 800px; margin: 0 auto; }
        .card {
            background: white;
            border-radius: 48px;
            overflow: hidden;
            box-shadow: 0 30px 50px -20px rgba(0,0,0,0.25);
        }
        .header {
            background: linear-gradient(115deg, #1e3c72, #2b4f8c);
            padding: 1.5rem 2rem;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .header a {
            background: rgba(255,255,255,0.2);
            padding: 8px 20px;
            border-radius: 40px;
            color: white;
            text-decoration: none;
        }
        .body { padding: 2rem; }
        .row {
            display: flex;
            gap: 1rem;
            padding: 1rem 0;
            border-bottom: 1px solid #edf2f7;
        }
        .icon {
            width: 45px;
            height: 45px;
            background: #eef3fc;
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2c7da0;
        }
        .label { font-size: 0.7rem; text-transform: uppercase; color: #7b8fa1; letter-spacing: 0.5px; }
        .value { font-weight: 500; margin-top: 5px; }
        .hobby-tag {
            background: #e1f0fa;
            padding: 5px 15px;
            border-radius: 50px;
            display: inline-block;
            margin: 5px 5px 0 0;
            font-size: 0.85rem;
        }
        .bio-box {
            background: #f8fcff;
            padding: 1rem;
            border-radius: 20px;
            margin-top: 5px;
        }
        .footer { text-align: center; padding: 1.5rem; color: #4a6885; }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <div class="header">
            <h1><i class="fas fa-id-card"></i> YOUR PROFILE</h1>
            <a href="index.html"><i class="fas fa-arrow-left"></i> Back to Form</a>
        </div>
        <div class="body">
            <div class="row">
                <div class="icon"><i class="fas fa-user"></i></div>
                <div style="flex:1"><div class="label">Name</div><div class="value">${fullName}</div></div>
            </div>
            <div class="row">
                <div class="icon"><i class="fas fa-id-badge"></i></div>
                <div style="flex:1"><div class="label">Student ID</div><div class="value">${studentId}</div></div>
            </div>
            <div class="row">
                <div class="icon"><i class="fas fa-graduation-cap"></i></div>
                <div style="flex:1"><div class="label">Program</div><div class="value">${program}</div></div>
            </div>
            <div class="row">
                <div class="icon"><i class="fas fa-envelope"></i></div>
                <div style="flex:1"><div class="label">Email</div><div class="value">${email}</div></div>
            </div>
            <div class="row">
                <div class="icon"><i class="fas fa-palette"></i></div>
                <div style="flex:1"><div class="label">Hobbies</div>
                    <div>
                        <% String h = (String)request.getAttribute("hobbiesRaw"); 
                           if(h != null) {
                               for(String hobby : h.split(",")) { %>
                                   <span class="hobby-tag"><i class="fas fa-heart"></i> <%= hobby.trim() %></span>
                        <%     }
                           } %>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="icon"><i class="fas fa-comment"></i></div>
                <div style="flex:1"><div class="label">About Me</div><div class="bio-box">${bio}</div></div>
            </div>
    </div>
</div>
</body>
</html>